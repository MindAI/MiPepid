Notes on the files of MiPepid's predictions on uORF and lncRNA:

Both of the files contain the following columns:
* `sORF_ID`: the ID of an sORF. 
* `sORF_seq`: the DNA sequence of the sORF (containing the stop codon with the start codon as `ATG`).
* `Ensembl_transcript_ID`: the ID of the corresponding transcript in the Ensembl database where this sORF is located.
* `Ensembl_transcript_biotype`: the biotype of the corresponding Ensembl transcript.
* `start_at`: the 1-based starting position of this sORF on the corresponding Ensembl transcript. 
* `end_at`: the 1-based ending position of this sORF on the corresponding Ensembl transcript.
* `classification`: the predicted class of the sORF, either `coding` or `noncoding`. 
* `probability`: the probability that this sORF is in the positive class.
