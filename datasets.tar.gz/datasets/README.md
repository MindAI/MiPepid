The `positive_original_data.csv` contains the general information of each data point in the positive dataset; Similarly, the `negative_original_data.csv` contains those in the negative dataset. Both the files contain data points in both the training and test set.

The `new_positive_original_data.xlsx` contains the general information of the data points in the `new_positive` test set.

The `train_feature.csv` contains the feature vector and label for each data point in the training set. Similarly, the `test_feature.csv` contains the info in the test set.



